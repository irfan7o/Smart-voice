<!DOCTYPE html>
    <head>
        <title>Smart Voice</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="images/Google.ico" type="image-icon" />   
        <style>
        #depan {
        background: #E7E7E7;
        border-radius: 15px;
        box-shadow: 1px 6px 8px rgba(0, 0, 0, 0.65);
        height: 410px;
        margin: 6rem auto 8.1rem auto;
        font-family: "Comic Sans MS", cursive, sans-serif;
        width: 500px;}

        .tbtl {
        width: auto;
        padding: 10px;
        outline: #00bfff;
        border-radius: 5px;
        }

        .bigNumber{
        font-size: 50px;
        }

        .dipencet { display: inline-block; padding: 8px 0px; font-size: 14px; margin-bottom: 12px; width: 39%; text-transform: uppercase; outline: none; color: #fff; background-color: #a8a7a7; border: none; text-align: center; position: relative; border-radius: 5px;  cursor: pointer; font-weight: bold;} 


        </style>
    </head>
    <center>
    <body>
    <div id="depan">
        <form action="index.php" method="POST">
        <img src="images/G.gif" width="100" height="100" style="padding-top: 40px; padding-bottom: 20px;">

        <?php
        if (isset($_POST["navigasi"])){
        $navigasi=$_POST["navigasi"];
        $nilai = $_POST["counter"];
        } ?>

        <table>
                <tr>
                    <td><input placeholder="Input Angka" type="text" name="counter" value=" <?php
                    $nilai = @$_POST["counter"];
                    if ($nilai==null){
                        echo "0";
                    }
                    if (isset($_POST["navigasi"])){
                        if ($navigasi=="prev"){
                            echo --$nilai;
                        }
                        elseif ($navigasi=="next"){
                            echo ++$nilai;
                        }
                    }
                ?>" class="tbtl"/></td>
                </tr>
            </table>
            <button type="submit" name="navigasi" value="prev" class="dipencet">Prev</button>
            <button type="submit" name="navigasi" value="next" class="dipencet">Next</button>
            <br/><br/>

            <div class="bigNumber">
                    <?php
                     include('audio.php');
                    if ($nilai==null){
                        echo "0";
                    }
                    else{
                        echo $nilai;
                    }
                    ?>
            </div>
        </form>
        <audio controls autoplay hidden>
  <source src="<?php echo $file; ?>" type="audio/mpeg">
Your browser does not support the audio element.
</audio>
        
    </div>   
    </body></center>
    <script
  src="https://code.jquery.com/jquery-3.5.1.min.js"
  integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
  crossorigin="anonymous"></script>
    <script ></script>
</hmtl>