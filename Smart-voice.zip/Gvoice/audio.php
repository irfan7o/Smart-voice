<?php 
require_once __DIR__ . "/vendor/autoload.php";
use duncan3dc\Speaker\TextToSpeech;
use duncan3dc\Speaker\Providers\GoogleProvider;

// $provider = new GoogleProvider;
// $tts = new TextToSpeech("3", $provider->withLanguage("id"));
// $tts->save("audio/3.mp3");
$mp3 = $nilai .'.mp3';
$file = 'audio/'.$mp3;
if (!file_exists($file)) {
    $provider = new GoogleProvider;
    $tts = new TextToSpeech($nilai, $provider->withLanguage("id"));
    $tts->save($file);
}


?>